import os

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from django.db import transaction
from django.db.models import F
from django.utils import timezone

from .models import Card

COLUMNS = ("todo", "doing", "done")


def card_to_dict(card):
    return {
        "id": card.id,
        "title": card.title,
        "column": card.column,
        "position": card.position,
        "version": card.version,
    }


class BoardConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        self.room_name = self.scope["url_route"]["kwargs"]["room_name"]
        if not self.user.is_authenticated or not self.room_name.isdigit():
            await self.close()
            return
        self.board_id = int(self.room_name)
        self.group_name = f"board_{self.board_id}"
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()
        await self.send_json({
            "type": "welcome",
            "user": self.user.username,
            "served_by": os.environ.get("WORKER_NAME", "local"),
            "server_time": timezone.now().isoformat(),
        })
        await self.send_board_state()

    async def disconnect(self, close_code):
        if hasattr(self, "group_name"):
            await self.channel_layer.group_discard(self.group_name, self.channel_name)

    @database_sync_to_async
    def get_cards(self):
        cards = Card.objects.filter(board_id=self.board_id).order_by("position", "id")
        return [card_to_dict(c) for c in cards]

    async def send_board_state(self):
        await self.send_json({"type": "board_state", "cards": await self.get_cards()})

    @database_sync_to_async
    def apply_move(self, card_id, to_column, position, version):
        # Tout se passe dans une seule transaction.
        with transaction.atomic():
            updated = Card.objects.filter(
                id=card_id, board_id=self.board_id, version=version
            ).update(column=to_column, position=position, version=F("version") + 1)
            card = Card.objects.filter(id=card_id, board_id=self.board_id).first()
        if card is None:
            return "missing", None
        if updated == 0:
            return "conflict", card_to_dict(card)
        return "moved", card_to_dict(card)

    async def handle_move_card(self, content):
        card_id = content.get("card_id")
        to_column = content.get("to_column")
        position = content.get("position")
        version = content.get("version")
        valid = (
            isinstance(card_id, int)
            and isinstance(position, int)
            and isinstance(version, int)
            and position >= 0
            and to_column in COLUMNS
        )
        if not valid:
            await self.send_json({"type": "error", "reason": "invalid"})
            return
        result, card = await self.apply_move(card_id, to_column, position, version)
        if result == "missing":
            await self.send_json({"type": "error", "reason": "card_not_found"})
        elif result == "conflict":
            await self.send_json(
                {"type": "conflict", "card_id": card_id, "current": card}
            )
        else:
            await self.channel_layer.group_send(
                self.group_name,
                {
                    "type": "broadcast.message",
                    "data": {
                        "type": "card_moved",
                        "card_id": card["id"],
                        "to_column": card["column"],
                        "position": card["position"],
                        "version": card["version"],
                        "by": self.user.username,
                    },
                },
            )

    async def receive_json(self, content):
        kind = content.get("type")
        if kind == "sync_request":
            await self.send_board_state()
        elif kind == "move_card":
            await self.handle_move_card(content)
        elif kind is None and "message" in content:
            # Chat de test, on le garde pour verifier les salles.
            content["user"] = self.user.username
            await self.channel_layer.group_send(
                self.group_name,
                {"type": "broadcast.message", "data": content},
            )
        else:
            await self.send_json({"type": "error", "reason": "invalid"})

    async def broadcast_message(self, event):
        await self.send_json(event["data"])